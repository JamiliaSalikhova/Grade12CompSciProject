// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "What is a general theory of relativity?",
    answer: "Time will pass slower for someone travelling near the speed of light, relative to someone sranding still",
    options: [
      "Time will pass slower for someone travelling near the speed of light, relative to someone sranding still",
      "Time will pass slower depending on the mass of the object",
      "Time depends on perspectives of the passanger's speed",
      "All of thr above"
    ]
  },
    {
    numb: 2,
    question: "Which of the following is true about the speed of light?",
    answer: "Light always travels at the same speed in empty space",
    options: [
      "Sound travels faster than light",
      "Bright light travels faster than dim light",
      "Light always travels at the same speed in empty space",
      "Light has no speed"
    ]
  },
    {
    numb: 3,
    question: "Who developed the theories of general and special relativity?",
    answer: "Albert Einstein developed both theories",
    options: [
      "Albert Einstein developed the theory of general relativity only",
      "Albert Einstein developed both theories",
      "Albert Einstein developed the theory of special relativity only",
      "Albert Einstein did not develop the theories, but he did prove them"
    ]
  },
    {
    numb: 4,
    question: "Which of the following statements is not true according to the theory of relativity?",
    answer: "As an object increases speed, its length increases",
    options: [
      "As an object increases speed, its length increases",
      "As an object increases speed, its mass increases",
      "As an object increases speed, its kinetic energy increases",
      "As an object increases speed, its momentum increases"
    ]
  },
    {
    numb: 5,
    question: "Compared to clocks in a stationary reference frame moving, clocks run…",
    answer: "Slower",
    options: [
      "Faster",
      "Slower",
      "At the same time",
      "They don't run"
    ]
  },
    {
    numb: 6,
    question: "True or False: As an object approaches the speed of light, time for that object speeds up, and it ages more quickly.",
    answer: "False",
    options: [
      "True",
      "False",
      "Neither",
      "I don't know"
    ]
  },
];